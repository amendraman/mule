package com.gdg.rocky;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class InsertInJdbc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sampledatabase?verifyServerCertificate=false&useSSL=true",
					"root", "Aarya_1998");
			Statement mySt = con.createStatement();
			String sql = "insert into employees " + " (id, last_name, first_name, email)"
							+ " values ('1', 'Brown', 'David', 'david.brown@gmail.com')";
			
			mySt.executeUpdate(sql);
			
			System.out.println("Insertion complete");
		}
		catch(Exception e)
		{
			
		}

	}

}
