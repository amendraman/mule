package com.gdg.rocky;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sampledatabase", "root", "Aarya_1998");
			// sampledatabase is the database name i created in mysql workbench
			Statement mySt = con.createStatement();
			ResultSet rst = mySt.executeQuery("SELECT * FROM EMPLOYEES");
			while(rst.next())
			{
				System.out.println(rst.getString("last_name") + ", " + rst.getString("first_name"));
			}
		}
		catch(Exception e)
		{
			
		}

	}

}
