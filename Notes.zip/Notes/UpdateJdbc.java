package com.gdg.rocky;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class UpdateJdbc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String url = "jdbc:mysql://localhost:3306/sampledatabase?verifyServerCertificate=false&useSSL=true";
		String user = "root";
		String password = "Aarya_1998";
		
		try{
			Connection con = DriverManager.getConnection(url, user, password);
			Statement mySt = con.createStatement();
			String sql = "update employees " + " set email='hifi@gmail.com'" + "where id = 3";
			
			mySt.executeUpdate(sql);
			System.out.println("update successful");
		}
		catch(Exception e)
		{
			
		}

	}

}
